# MyPlugin
ver 1.0.1
Classification: FileImporter

Overview
-----
MyImporter is an importer plugin which currently cannot import data
but is used to help developers writing their own plugins.

Data example
-----
It does not support any data :)

Configuration
-----
The Sample plugin offers the following configuration options:

| key  | value | description | required |
| ------------- | ------------- |  ------------- | ------------- |
| compatiblePlugins | Plugin1, Plugin2... | Other plugins known to be compatible with this plugin, can be empty | x |

Required Plugins
-----
 - no other plugins required